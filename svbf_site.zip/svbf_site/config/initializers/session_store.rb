# Be sure to restart your server when you modify this file.

SvbfSite::Application.config.session_store :cookie_store, key: '_svbf_site_session'
