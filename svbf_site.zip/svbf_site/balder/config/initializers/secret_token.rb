# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Balder::Application.config.secret_token = '23aabccbfd8e48ab8b96104ba699a1603e6bad13a125317be3ed9963c18cd24b9afa725d218688202f3752fd693cc8358f522c0f18c42a5a0b8ce3c84a8b89a2'
